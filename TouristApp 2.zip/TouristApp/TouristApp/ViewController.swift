//
//  ViewController.swift
//  TouristApp
//
//  Created by Aeman Rehman on 3/7/23.
//
// Disclaimer: This App is developed as an educational project.
// Certain materials are included under the fair use exemption of the U.S. Copyright
// Law and have been prepared according to the multimedia fair use guidelines and are
// restricted from further use.
//


import UIKit
import AVFoundation
import AVKit

class ViewController: UIViewController {
    
    var SplitViewT:Rand = Rand()
    
    
    
    
    var mySoundFile:AVAudioPlayer!
    
    

   
    
    @IBOutlet weak var heading: UILabel!
    @IBOutlet weak var pic: UIImageView!
    @IBOutlet weak var desc: UILabel!
    
    

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let  urlObject = URL(fileURLWithPath: Bundle.main.path(forResource: "pak-instrument", ofType: "wav")!)
         
         mySoundFile = try? AVAudioPlayer(contentsOf:urlObject)
        
        setRand()
    }
    
    override func motionBegan(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        pic.alpha = 0.5
        heading.alpha = 0.5
        desc.alpha = 0.5
        
    }
    
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        UIView.animate(withDuration: 3, animations: {
            self.pic.alpha = 1
            self.heading.alpha = 1
            self.desc.alpha = 1
            
        })
        setRand()
    }
    
    
    func setRand(){
        var random = SplitViewT
        heading.text = random.title
        desc.text = random.descr
        desc.adjustsFontSizeToFitWidth = true
        pic.image = UIImage(named: random.img)
        pic.layer.cornerRadius = 3
        pic.clipsToBounds = true
        pic.layer.borderWidth = 5
        pic.layer.borderColor = UIColor.yellow.cgColor
        mySoundFile.play()
    }
    


    
}
