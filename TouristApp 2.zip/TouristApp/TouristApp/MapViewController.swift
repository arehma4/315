//
//  MapViewController.swift
//  TouristApp
//
//  Created by user235234 on 5/8/23.
//

import Foundation
import UIKit
import MapKit
import CoreLocation

class MapViewController: UIViewController {
    
    
    
    @IBOutlet weak var mapView: MKMapView!
    
    
    let locationManager:CLLocationManager = CLLocationManager()
    
    
    override func viewDidLoad() {
        locationManager.requestWhenInUseAuthorization()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = kCLDistanceFilterNone
        locationManager.startUpdatingLocation()
        
        mapView.showsUserLocation = true
        mapView.userTrackingMode = .follow
    }
    
    
}
