//
//  TouristListController.swift
//  TouristApp
//
//  Created by user235234 on 5/6/23.
//

import Foundation
import UIKit

class TouristListController : UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        GetJSONData()
    }
    
    var LocationOA = [Rand]()
    var MosquesOA = [Rand]()
    var FoodsOA = [Rand]()
    var AttractionsOA = [Rand]()
    

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // the Segue knows the destination controller.
        var destController = segue.destination as! ViewController
        // find the selected row index from the tableview
        let index = tableView.indexPathForSelectedRow
        // find the matching row in the object array
        
        let selectedRow = index!.row
        // set the destinaiton controller Hiking Trail object with the object from the selected tableView row.
        switch index!.section {
        case 0:
            destController.SplitViewT = LocationOA[selectedRow]
        case 1:
            destController.SplitViewT = MosquesOA[selectedRow]
        case 2:
            destController.SplitViewT = FoodsOA[selectedRow]
        case 3:
            destController.SplitViewT = AttractionsOA[selectedRow]
        default:
            break
        }
        
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }
    
    

    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
 
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int ) -> String? {
        if section == 0 {
            return "CITIES"
            
        }
        if section == 1 {
            return "MOSQUES"
            
        }
        if section == 2 {
            return "FOOD"
            
        }
        else {
            return "ATTRACTIONS"
            
        }

    }
    
    override func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        guard let header = view as? UITableViewHeaderFooterView else { return }
        header.textLabel?.textColor = UIColor(red: 250/255, green: 226/255, blue: 109/255, alpha: 1)
        header.textLabel?.frame = header.contentView.bounds // Expand the label size
        header.textLabel?.backgroundColor = UIColor(red: 36/255, green: 138/255, blue: 17/255, alpha: 1)
        header.textLabel?.font = UIFont.boldSystemFont(ofSize: 20)
    }


    
    

    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var myCell = tableView.dequeueReusableCell(withIdentifier: "myCellID")
        var cellIndex = indexPath.row

        switch indexPath.section {
        case 0:
            var Tour = LocationOA[cellIndex]
            myCell!.textLabel!.text = Tour.title
            
        case 1:
            var Tour = MosquesOA[cellIndex]
            myCell!.textLabel!.text = Tour.title
            
        case 2:
            var Tour = FoodsOA[cellIndex]
            myCell!.textLabel!.text = Tour.title
            
        case 3:
            var Tour = AttractionsOA[cellIndex]
            myCell!.textLabel!.text = Tour.title

            
        default:
            break
        }
        
        myCell!.textLabel!.font = UIFont.boldSystemFont(ofSize: 18)
        
        myCell!.textLabel!.textColor = UIColor(red: 36/255, green: 138/255, blue: 17/255, alpha: 1)
        myCell!.textLabel!.backgroundColor = UIColor(red: 250/255, green: 226/255, blue: 109/255, alpha: 1)

        

        return myCell!
    }
    
    func GetJSONData() {
        
        // Use the String address and convert it to a URL type
        let endPointString  = "https://raw.githubusercontent.com/arehma4/315/main/Item.json"
        let endPointURL = URL(string: endPointString)
        
        // Pass it to the Data function
        
        let dataBytes = try? Data(contentsOf:endPointURL!)
        // Receive the bytes
        //print(dataBytes) // just for developers to see what is received. this will help in debugging
        
        
        if (dataBytes != nil) {
            // get the JSON Objects and convert it to a Dictionary
            let dictionary:NSDictionary = (try! JSONSerialization.jsonObject(with: dataBytes!, options: JSONSerialization.ReadingOptions.mutableContainers)) as! NSDictionary
            
            print("Dictionary --:  \(dictionary) ---- \n") // for debugging purposes
            
            // Split the Dictionary into two parts. Keep the HikingTrails Part and discard the other
            let LocDict = dictionary["Location"]! as! [[String:AnyObject]]
            let MosDict = dictionary["Mosque"]! as! [[String:AnyObject]]
            let FoodDict = dictionary["Food"]! as! [[String:AnyObject]]
            let AttDict = dictionary["Attraction"]! as! [[String:AnyObject]]
            
            for index in 0...LocDict.count - 1  {
                // Dictionary to Single Object (Hiking Trail)
                let singleT = LocDict[index]
                // create the Hiking Trail Object
                let tr = Rand()
                //reterive each object from the dictionary
                tr.title = singleT["Title"] as! String
                //ht. = singleHT["TrailAddress"] as! String
                tr.descr = singleT["Desc"] as! String
                tr.img = singleT["Image"] as! String
                LocationOA.append(tr)
            }
            
            for index in 0...MosDict.count - 1  {
                // Dictionary to Single Object (Hiking Trail)
                let singleT = MosDict[index]
                // create the Hiking Trail Object
                let tr = Rand()
                //reterive each object from the dictionary
                tr.title = singleT["Title"] as! String
                //ht. = singleHT["TrailAddress"] as! String
                tr.descr = singleT["Desc"] as! String
                tr.img = singleT["Image"] as! String
                MosquesOA.append(tr)
            }
            
            for index in 0...FoodDict.count - 1  {
                // Dictionary to Single Object (Hiking Trail)
                let singleT = FoodDict[index]
                // create the Hiking Trail Object
                let tr = Rand()
                //reterive each object from the dictionary
                tr.title = singleT["Title"] as! String
                //ht. = singleHT["TrailAddress"] as! String
                tr.descr = singleT["Desc"] as! String
                tr.img = singleT["Image"] as! String
                FoodsOA.append(tr)
            }
            
            for index in 0...AttDict.count - 1  {
                // Dictionary to Single Object (Hiking Trail)
                let singleT = AttDict[index]
                // create the Hiking Trail Object
                let tr = Rand()
                //reterive each object from the dictionary
                tr.title = singleT["Title"] as! String
                //ht. = singleHT["TrailAddress"] as! String
                tr.descr = singleT["Desc"] as! String
                tr.img = singleT["Image"] as! String
                AttractionsOA.append(tr)
            }
            
            
        }
    }
    
    
    

    
    
    
    
}
