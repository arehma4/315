//
//  Tour.swift
//  TouristApp
//
//  Created by Aeman Rehman on 3/22/23.
//

import Foundation
import UIKit



class Rand {
    var title = ""
    var img = ""
    var descr = ""
}
