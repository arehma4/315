//
//  WebViewController.swift
//  TouristApp
//
//  Created by user235234 on 5/7/23.
//

import Foundation
import WebKit

class WebViewController : UIViewController {
    
    
    @IBOutlet weak var WVSite: WKWebView!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        let siteURL = URL(string: "https://us.trip.com/travel-guide/destination/pakistan-100114/")
        
        let request = URLRequest(url:siteURL!)
        
        WVSite.load(request)
    }
    
    
}
